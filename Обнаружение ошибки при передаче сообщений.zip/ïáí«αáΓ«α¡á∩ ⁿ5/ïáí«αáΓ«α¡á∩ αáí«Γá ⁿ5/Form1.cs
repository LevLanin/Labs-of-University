﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабораторная_работа__5
{
    public partial class Form1 : Form
    {
        Form2 forma2;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string txt = textBox1.Text;     //Сообщение
            int kol_bukv = txt.Length;      //Длина сообщения
            string alfavit = "0123456789abcdefghijklmnopqrstuvwxyz_";   //Алфавит
            int summ=0, summ_summ=0;        //для нахождения Сумма и сумма сумм
            int[,] matrix = new int[kol_bukv,2];    //данные обоих сумм
            int x;

            dataGridView1.RowCount = kol_bukv + 1;  //кол-во строк
            dataGridView1.ColumnCount = 3;  //кол-во столбцов
            dataGridView1.Columns[0].HeaderText = "Символ"; //заполение заголовков столбцов
            dataGridView1.Columns[1].HeaderText = "Сумма";
            dataGridView1.Columns[2].HeaderText = "Сумма сумм";

            for (int i = 0; i < kol_bukv; i++)              //заполнение таблицы, и матрицы данных 
            {
                dataGridView1.Rows[i].Cells[0].Value = "" + txt[i]+"="+alfavit.IndexOf(txt[i]);
                summ += alfavit.IndexOf(txt[i]);
                summ_summ += summ;
                dataGridView1.Rows[i].Cells[1].Value = summ;
                dataGridView1.Rows[i].Cells[2].Value = summ_summ;
                matrix[i, 0] = summ;
                matrix[i, 1] = summ_summ;
            }
            dataGridView1.Rows[kol_bukv].Cells[0].Value = "Ключ=X";
            dataGridView1.Rows[kol_bukv].Cells[1].Value = matrix[kol_bukv-1, 0]+"+X";
            dataGridView1.Rows[kol_bukv].Cells[2].Value = matrix[kol_bukv-1, 1]+matrix[kol_bukv-1,0]+"+X" ;
            x = 37 - (matrix[kol_bukv - 1, 1] + matrix[kol_bukv - 1, 0]) % 37;

            string text_message = txt + alfavit[x];

            DialogResult result = MessageBox.Show("Закодированное сообщение: " + text_message + ". Перед отправлением сделать ошибку?", "Вывод", MessageBoxButtons.YesNo);

            Random rnd = new Random();

            if (result==DialogResult.Yes)
            {
                char[] charStr = text_message.ToCharArray();
                charStr[rnd.Next(0, kol_bukv - 1)] = alfavit[rnd.Next(0, 36)];
                text_message = new string(charStr);
            }
           

            forma2 = new Form2();
            forma2.Show();
            forma2.textBox1.Text = text_message;
            

        }
    }
}
