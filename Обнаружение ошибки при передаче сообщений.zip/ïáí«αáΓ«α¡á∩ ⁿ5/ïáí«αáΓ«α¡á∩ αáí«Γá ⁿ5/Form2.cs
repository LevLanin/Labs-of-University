﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабораторная_работа__5
{
    public partial class Form2 : Form
    { 
        public Form2()
        {
            InitializeComponent();
        }

        private static int proverka(string txt)
        {
            int n=0;
            string alfavit = "0123456789abcdefghijklmnopqrstuvwxyz_";

            for (int i = 0,j=txt.Length; i < txt.Length; i++,j--)
            {
                n += alfavit.IndexOf(txt[i]) * j;
            }
            n = n % 37;
            return n;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string pol_txt = textBox1.Text;
            if (proverka(pol_txt) == 0)
            {
                MessageBox.Show("Ошибки нет!", "Наличие ошибок", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Есть Ошибка! N="+proverka(pol_txt), "Наличие ошибок", MessageBoxButtons.OK);
            }


        }

       
    }
}
