﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабораторная__6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label6.Visible = false;
        }

        public static int Dlina(string s)
        {
            int dlina = s.Length;

            double kontr_bit = Math.Ceiling(Math.Log(s.Length, 2));   //нужно для нахождения контрольных битов
            int n = Convert.ToInt16(kontr_bit);     //кол-во контр битов

            if (Math.Ceiling(Math.Log(dlina+ n, 2))>n)
            {
                n++;
            }
            return n;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string txt = textBox1.Text;     //текст сообщения
            int kol_bukv = txt.Length;      //длина сообщения
            int kol_kontr_bit = Dlina(txt);     //кол-во контр битов

            
            int kol_poln_txt = kol_bukv + kol_kontr_bit;        //кол-во символом в полном сообщении
            int[] mat_simvol = new int[kol_poln_txt];      //сообщение с контр. битами
            int[,] matrix = new int[kol_kontr_bit, kol_poln_txt+2];   //матрица преобразования
            int[] mat_kontr = new int[kol_kontr_bit];

            string pered_txt = "";  //переданное сообщение
            string poluch_txt = ""; //полученное сообщение
            string isprav_txt = ""; //исправленное сообщение

            dataGridView1.RowCount = (2+kol_kontr_bit)*2;
            dataGridView1.ColumnCount = kol_poln_txt + 2;
            for (int i = 0; i < kol_poln_txt; i++)
            {
                
            }

            int kontr=1,r=0,x=0;    //для корректного заполнения таблицы
            for (int i = 0; i < kol_poln_txt; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Value = "" + (i + 1);   //заголовок
                //заполняю первую и вторую строку таблицы
                if (i==kontr-1)
                {
                    dataGridView1[i, 0].Value = "R" + r;
                    dataGridView1[i, (2+kol_kontr_bit)].Value = "R" + r;
                    dataGridView1[i, 1].Value = "0";
                    mat_simvol[i] = 0;
                    dataGridView1.Rows[1].Cells[i].Style.BackColor = System.Drawing.Color.Pink;
                    dataGridView1.Rows[(3 + kol_kontr_bit)].Cells[i].Style.BackColor = System.Drawing.Color.Pink;
                    r++;
                    kontr *= 2;
                    
                }
                else
                {
                    dataGridView1[i, 0].Value = "X" + (x+1);
                    dataGridView1[i, (2 + kol_kontr_bit)].Value = "X" + (x + 1);
                    dataGridView1[i, 1].Value = txt[x];
                    if (txt[x]=='1')
                    {
                        mat_simvol[i] = 1;
                    }
                    else
                    {
                        mat_simvol[i] = 0;
                    }
                    x++;
                }
                
            }
            //матрица преобразования
            int gg=1;  
            for (int i = 2; i < kol_kontr_bit + 2; i++)
            {
                for (int j = 0; j < kol_poln_txt+2;)
                {
                    int g = 0;
                    while (g<gg && j<kol_poln_txt+2)
                    {
                        dataGridView1[j, i].Value = "0";
                        matrix[i - 2, j] = 0;
                        j++;
                        g++;
                    }
                    g = 0;
                    while (g < gg && j < kol_poln_txt+2)
                    {
                        dataGridView1[j, i].Value = "1";
                        matrix[i - 2, j] = 1;
                        j++;
                        g++;
                    }
                }
                gg *= 2;
                //последний столбец
                int rr=0;
                for (int j = 0; j < kol_poln_txt + 1; j++)
                {
                    matrix[i - 2, j] = matrix[i - 2, j + 1];
                    dataGridView1[j, i].Value = matrix[i-2,j];
                    
                }
                for (int j = 0; j < kol_poln_txt; j++)
                {
                    rr+=matrix[i-2,j]*mat_simvol[j];
                }
                mat_kontr[i-2] = rr % 2;
                dataGridView1[dataGridView1.ColumnCount - 1, i].Value = mat_kontr[i-2];
                dataGridView1[kol_poln_txt, i].Value = "R" + (i - 2);
            }

            int kontr_2 = 1, r_2 = 0;    //Переданное сообщение
            for (int i = 0; i < kol_poln_txt; i++)
            {
                
                if (i == kontr_2 - 1)
                {
                    pered_txt += mat_kontr[r_2];
                    r_2++;
                    kontr_2 *= 2;

                }
                else
                {
                    pered_txt += mat_simvol[i];
                }
            }
            label3.Text = pered_txt;

            //Сделать ли ошибку
            if (DialogResult.Yes == MessageBox.Show("Вставить ошибку?","Передача сообщения",MessageBoxButtons.YesNo))
            //Ошибка
            {
                Random rnd = new Random();
                int a = rnd.Next(0, kol_poln_txt);
                char[] charStr = pered_txt.ToCharArray();
                if (charStr[a] == '0')
                {
                    charStr[a] = '1';
                }
                else
                {
                    charStr[a] = '0';
                }
                poluch_txt = new string(charStr);
                dataGridView1.Rows[3+kol_kontr_bit].Cells[a].Style.BackColor = System.Drawing.Color.Red;
                for (int i = 0; i < pered_txt.Length; i++) { dataGridView1[i, (3 + kol_kontr_bit)].Value = poluch_txt[i]; }
            }
            //Нет ошибки
            else
            {
                for (int i = 0; i < pered_txt.Length; i++) { dataGridView1[i, (3 + kol_kontr_bit)].Value = pered_txt[i]; }
                poluch_txt = pered_txt;
            }
            label5.Text = poluch_txt;

            //Заполнение таблицы 2
            for (int i = 4+kol_kontr_bit; i < (4+kol_kontr_bit*2); i++)
            {   
                for (int j = 0; j < kol_poln_txt; j++)
                {
                    dataGridView1[j, i].Value = matrix[(i-4-kol_kontr_bit), j];
                }

                int ss = 0;
                for (int j = 0; j < kol_poln_txt; j++)
                {
                    ss += matrix[(i - 4 - kol_kontr_bit), j] * poluch_txt[j];
                }
                mat_kontr[(i - 4 - kol_kontr_bit)] = ss % 2;
                dataGridView1[dataGridView1.ColumnCount - 1, i].Value = mat_kontr[(i - 4 - kol_kontr_bit)];
                dataGridView1[kol_poln_txt, i].Value = "S" + ((i - 4 - kol_kontr_bit));

            }

            //Поиск и исправление ошибки
            int oshibka,net_oshibki;
            for (int i = 0; i < 20; i++)
            {
                oshibka = 0;
                net_oshibki = 0;
                for (int j = 0; j < kol_kontr_bit; j++)
                {
                    if (mat_kontr[j]==matrix[j,i])
                    {
                        oshibka++;
                    }
                    if (mat_kontr[j]==0)
                    {
                        net_oshibki++;
                    }
                }
                if (net_oshibki == kol_kontr_bit)
                {
                    MessageBox.Show("Ошибка не найдена!", "Поиск ошибки!", MessageBoxButtons.OK);
                    i = kol_poln_txt;
                }
                if (oshibka == kol_kontr_bit)
                {
                    MessageBox.Show("Ошибка найдена на " + (i+1) + "-ом месте!", "Поиск ошибки", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    label6.Visible = true;
                    char[] charStr = poluch_txt.ToCharArray();
                    if (charStr[i] == '0')
                    {
                        charStr[i] = '1';
                    }
                    else
                    {
                        charStr[i] = '0';
                    }
                    isprav_txt = new string(charStr);
                    label7.Text = isprav_txt;
                    i = kol_poln_txt;
                }
            }
        }
    }
}
