﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лаб._4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int Popolam(int nachalo, int konec, int[] matr)
        {

            int summa2 = 0, seredina = nachalo;
            for (int i = nachalo+1; i <= konec ; i++)
            {
                summa2 = summa2 + matr[i];
            }

            int summa1 = matr[0], summa3 = 0;
            while (summa1 <= summa2 || Math.Abs(summa1-summa2)<Math.Abs(summa1-summa3))
            {   
                seredina++;
                summa3 = summa1;
                summa1 += matr[seredina];
                summa2 -= matr[seredina];
            }
            return seredina-1;


        }

        public void SH_F(int nachalo, int konec, string[] kodir, char[] alf,int[] matr,int kol)
        {
            int seredina;
            if (nachalo < konec)
            {
                dataGridView1.RowCount += 2;
                seredina = Popolam(nachalo, konec, matr);
                dataGridView1.Rows[dataGridView1.RowCount - 4].HeaderCell.Value = "Символ";
                dataGridView1.Rows[dataGridView1.RowCount - 3].HeaderCell.Value = "Вероят.";
                for (int i = nachalo; i <= konec; i++)
                {
                    if (i <= seredina)
                    {
                        kodir[i] +="0";
                    }
                    else
                    {
                        kodir[i] += "1";
                    }
                }

                for (int j = 0; j < konec - nachalo + 1; j++)
                {
                    dataGridView1[j, dataGridView1.RowCount-4].Value = alf[nachalo + j];
                    dataGridView1[j, dataGridView1.RowCount-3].Value = matr[nachalo + j]+"/"+kol;
                    
                }
                int z = 0;
                while (z < seredina-nachalo+1)
                {
                    dataGridView1.Rows[dataGridView1.RowCount - 4].Cells[z].Style.BackColor = System.Drawing.Color.Gray;
                    dataGridView1.Rows[dataGridView1.RowCount - 3].Cells[z].Style.BackColor = System.Drawing.Color.Gray;
                    z++;
                }
                SH_F(seredina + 1, konec, kodir, alf, matr,kol);    //на вторую половину

                SH_F(nachalo, seredina,kodir,alf,matr,kol); //на первую половину

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string txt = textBox1.Text; //повторяющийся текст
            int koltxt = txt.Length;    //кол-во букв в повторяющемся тексте

            string alfavit = txt;   //объявление алфавита, который используется в тексте
            int kolbukv = koltxt;   //кол-во букв в алфавите
            char simvol;    //символьная переменная, нужна для составления алфавита
            int kolvh = 0; //для счёта букв в алфавите

            for (int i = 0; i < kolbukv; i++)
            {
                simvol = alfavit[i];

                for (int j = i + 1; j < kolbukv; j++)
                {
                    if (alfavit[j] == simvol)
                    {
                        alfavit = alfavit.Remove(j, 1);    //удаление повторяющейся буквы
                        j--;        //чтобы после удаления букв, вернулся на место удалённой буквы
                        kolbukv--; //чтобы не вылез за пределы строки
                    }
                }
            }

            int[] matrix1 = new int[kolbukv];  //массив для хранения данных из однобуквенной таблицы
            string[] tabl_simvol = new string[kolbukv]; //для хранения символов
            string[] kodirovka = new string[kolbukv];   //массив строк для кодировки

            dataGridView1.RowCount = 4;                     //создание таблицы
            dataGridView1.RowHeadersWidth = 80;
            dataGridView1.Rows[0].HeaderCell.Value = "Символ";
            dataGridView1.Rows[1].HeaderCell.Value = "Вероят.";
            dataGridView1.ColumnCount = kolbukv;
            for (int i = 0; i < kolbukv; i++)                   //первая таблица
            {
                tabl_simvol[i] = "" + alfavit[i];
                dataGridView1[i, 0].Value = tabl_simvol[i];
                dataGridView1.Columns[i].Width = 50;
                kolvh = 0;
                for (int z = 0; z < koltxt; z++)
                {
                    if (alfavit[i] == txt[z])
                    {
                        kolvh++;
                    }
                }

                dataGridView1[i, 1].Value = kolvh + "/" + koltxt;    //заполняется вторая строка
                matrix1[i] = kolvh;                               //заполняется массив вычислений
            }

            int kol_bukv = kolbukv;     //запоминаю количество букв

            //Сортировка
            char[] sort_alfavit = alfavit.ToCharArray();    
            int temp_kod;
            string temp_kod_s;

            for (int i = 0; i < kolbukv; i++)                   
            {
                for (int j = 0; j < kolbukv - 1; j++)
                {
                    if (matrix1[j] > matrix1[j + 1])
                    {
                        temp_kod = matrix1[j + 1];
                        matrix1[j + 1] = matrix1[j];
                        matrix1[j] = temp_kod;
                        temp_kod_s = "" + sort_alfavit[j + 1];
                        sort_alfavit[j + 1] = sort_alfavit[j];
                        sort_alfavit[j] = Convert.ToChar(temp_kod_s);
                    }

                }                
            }

          

            //Метод Шенона-Фано
            SH_F(0, kolbukv - 1, kodirovka, sort_alfavit, matrix1,koltxt);
            dataGridView1.Rows[dataGridView1.RowCount - 2].HeaderCell.Value = "Символ";
            dataGridView1.Rows[dataGridView1.RowCount - 1].HeaderCell.Value = "Код";
            for (int i = 0; i < kolbukv; i++)
            {
                dataGridView1[i, dataGridView1.RowCount - 2].Value = sort_alfavit[i];
                dataGridView1[i, dataGridView1.RowCount - 1].Value = kodirovka[i];
            }

                        
        }
    }
}
