﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string istext = ishtext1.Text, vivtext = "";      //Объявляю переменные  для шифр/расшифр

            int kluch = int.Parse(key1.Text);      //Ключ
            int sdvig;

            string alfavit = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";       //Алфавит

            for (int i = 0; i < istext.Length; i++)
            {
                sdvig = 0;
                for (int j = 0; j < 33; j++)
                {
                    if (istext[i]==alfavit[j])
                    {
                        sdvig = j + kluch;
                        while (sdvig>32)
                        {
                            sdvig -= 33;
                        }
                        vivtext = vivtext + alfavit[sdvig];
                    }
                }
            }

            vivod1.Text = vivtext;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string istext = ishtext2.Text, vivtext = "";      //Объявляю переменные  для шифр/расшифр

            int kluch = int.Parse(key2.Text);      //Ключ
            int sdvig;

            string alfavit = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";       //Алфавит

            for (int i = 0; i < istext.Length; i++)
            {
                sdvig = 0;
                for (int j = 0; j < 33; j++)
                {
                    if (istext[i] == alfavit[j])
                    {
                        sdvig = j - kluch;
                        while (sdvig < 0)
                        {
                            sdvig += 33;
                        }
                        vivtext = vivtext + alfavit[sdvig];
                    }
                }
            }

            vivod2.Text = vivtext;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            string istext = ishtext3.Text, vivtext = "";      //Объявляю переменные  для шифр/расшифр

            string kluch = key3.Text;      //Ключ
            int j = 0;

            for (int i=0;i<istext.Length;i++, j++)
            {
                vivtext += (char)(istext[i] ^ kluch[j]);
                if (j> istext.Length-1)
                {
                    j -= istext.Length;
                }
            }

            vivod3.Text = vivtext;
           
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            string istext = ishtext4.Text, vivtext = "";      //Объявляю переменные  для шифр/расшифр

            string kluch = key4.Text;      //Ключ
            int j = 0;

            for (int i = 0; i < istext.Length; i++, j++)
            {
                vivtext += (char)(istext[i] ^ kluch[j]);
                if (j > istext.Length - 1)
                {
                    j -= istext.Length;
                }
            }

            vivod4.Text = vivtext;
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            string istext = ishtext1.Text, vivtext = "";      //Объявляю переменные  для шифр/расшифр

            int kluch = int.Parse(key1.Text);      //Ключ
            int sdvig;

            string alfavit = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";       //Алфавит

            for (int i = 0; i < istext.Length; i++)
            {
                sdvig = 0;
                for (int j = 0; j < 33; j++)
                {
                    if (istext[i] == alfavit[j])
                    {
                        sdvig = j + kluch;
                        while (sdvig > 32)
                        {
                            sdvig -= 33;
                        }
                        vivtext = vivtext + alfavit[sdvig];
                    }
                }
            }

            vivod1.Text = vivtext;
        }
    }
}
