﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string txt = textBox1.Text; //повторяющийся текст
            int koltxt = txt.Length;    //кол-во букв в повторяющемся тексте
            
            string alfavit = txt;   //объявление алфавита, который используется в тексте
            int kolbukv = koltxt;   //кол-во букв в алфавите
            char simvol;    //символьная переменная, нужна для составления алфавита
            int kolvh = 0; //для счёта букв в алфавите

            for (int i = 0; i < kolbukv; i++)
            {
                simvol = alfavit[i];
                
                for (int j = i+1; j < kolbukv; j++)
                {
                    if (alfavit[j]==simvol)     
                    {
                        alfavit=alfavit.Remove(j,1);    //удаление повторяющейся буквы
                        j--;        //чтобы после удаления букв, вернулся на место удалённой буквы
                        kolbukv--; //чтобы не вылез за пределы строки
                    }
                }
            }
            
            int[] matrix1 = new int[kolbukv];  //массив для хранения данных из однобуквенной таблицы
            int[] matrix2 = new int[kolbukv];
            string[] tabl_simvol = new string[kolbukv]; //для хранения символов
            string[] kodirovka = new string[kolbukv];   //массив строк для кодировки

            dataGridView1.RowCount = 4*kolbukv;                     //создание таблицы
            dataGridView1.RowHeadersWidth = 80;
            dataGridView1.Rows[0].HeaderCell.Value = "Символ";
            dataGridView1.Rows[1].HeaderCell.Value = "Вероят.";
            dataGridView1.ColumnCount = kolbukv;
            for (int i = 0; i < kolbukv; i++)                   //первая таблица
            {
                tabl_simvol[i] = ""+alfavit[i];
                dataGridView1[i, 0].Value = tabl_simvol[i];
                dataGridView1.Columns[i].Width = 50;
                kolvh = 0;
                for (int z = 0; z < koltxt; z++)
                {
                     if (alfavit[i] == txt[z])
                     {
                         kolvh++;
                     }
                }

                dataGridView1[i, 1].Value = kolvh+"/"+koltxt;    //заполняется вторая строка
                matrix1[i] = kolvh;                               //заполняется массив вычислений
                matrix2[i] = kolvh;
            }

            int kol_bukv = kolbukv;     //запоминаю количество букв

            //отсортированный алфавит
            char[] sort_alfavit = alfavit.ToCharArray();
            int temp_kod;
            string temp_kod_s;

            for (int i = 0; i < matrix2.Length; i++)
            {
                for (int j = 0; j < matrix2.Length - 1; j++)
                {
                    if (matrix2[j] < matrix2[j + 1])
                    {
                        temp_kod = matrix2[j + 1];
                        matrix2[j + 1] = matrix2[j];
                        matrix2[j] = temp_kod;
                        temp_kod_s =""+sort_alfavit[j + 1];
                        sort_alfavit[j + 1] = sort_alfavit[j];
                        sort_alfavit[j] =Convert.ToChar(temp_kod_s);
                    }

                }

            }

            for (int z = 1; z < kol_bukv; z++)
            {
                dataGridView1.Rows[4 * z-2].HeaderCell.Value = "Символ";
                dataGridView1.Rows[4 * z -1].HeaderCell.Value = "Вероят.";

                int temp;                                           //сортировка
                string temp_s;

                for (int i = 0; i < matrix1.Length; i++)
                {
                    for (int j = 0; j < matrix1.Length-1; j++)
                    {
                        if (matrix1[j] < matrix1[j+1])
                        {
                            temp = matrix1[j+1];
                            matrix1[j+1] = matrix1[j];
                            matrix1[j] = temp;
                            temp_s = tabl_simvol[j + 1];
                            tabl_simvol[j+1] = tabl_simvol[j];
                            tabl_simvol[j] = temp_s;
                        }

                    }

                }
                for (int i = 0; i < kolbukv; i++)                                   //Сортировочная таблица
                {
                    dataGridView1[i, 4 * z-2].Value = tabl_simvol[i];
                    dataGridView1[i, 4*z-1].Value = matrix1[i] + "/" + koltxt;
                }
                int a = tabl_simvol[kolbukv - 2].Length;
                for (int i = 0; i < tabl_simvol[kolbukv - 2].Length; i++)
                {
                    for (int j = 0; j < kol_bukv; j++)
                    {
                        
                        if (sort_alfavit[j] == tabl_simvol[kolbukv - 2][i])
                        {
                            kodirovka[j] = "0" + kodirovka[j];
                        }
                    }
                    
                    
                }
                for (int i = 0; i < tabl_simvol[kolbukv - 1].Length; i++)
                {
                    for (int j = 0; j < kol_bukv; j++)
                    {
                        if (sort_alfavit[j] == tabl_simvol[kolbukv - 1][i])
                        {
                            kodirovka[j] = "1" + kodirovka[j];
                        }
                    }
                    
                }

                dataGridView1.Rows[4 * z].HeaderCell.Value = "Символ";              //Новая таблица    
                dataGridView1.Rows[4 * z + 1].HeaderCell.Value = "Вероят.";         

                matrix1[kolbukv - 2] += matrix1[kolbukv - 1];                       //Вычисляю новые вероятности
                matrix1[kolbukv - 1] = 0;                                           
                matrix1 = matrix1.Where(x => x != 0).ToArray();

                tabl_simvol[kolbukv - 2] += tabl_simvol[kolbukv - 1];               //Вычисляю новые символы
                tabl_simvol[kolbukv - 1] = null;
                tabl_simvol = tabl_simvol.Where(x => x != null).ToArray();

                

                kolbukv--;

                for (int i = 0; i < kolbukv; i++)                       
                {
                    dataGridView1[i, 4 * z].Value = tabl_simvol[i];
                    dataGridView1[i, 4 * z + 1].Value = matrix1[i] + "/" + koltxt;
                }
            }
            //Кодировка
            dataGridView2.RowCount = 3;                    
            dataGridView2.RowHeadersWidth = 80;
            dataGridView2.Rows[0].HeaderCell.Value = "Символ";
            dataGridView2.Rows[1].HeaderCell.Value = "Вероят.";
            dataGridView2.ColumnCount = kol_bukv;
            for (int i = 0; i < kol_bukv; i++)
            {
                dataGridView2[i, 0].Value = dataGridView1[i, 2].Value;
                dataGridView2[i, 1].Value = dataGridView1[i, 3].Value;
                dataGridView2[i, 2].Value = kodirovka[i];
            }


        }
    }
}
