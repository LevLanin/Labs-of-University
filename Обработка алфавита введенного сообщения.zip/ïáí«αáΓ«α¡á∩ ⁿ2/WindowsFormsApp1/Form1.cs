﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string txt = textBox1.Text; ///повторяющийся текст
            int koltxt = txt.Length;    ///кол-во букв в повторяющемся тексте
            
            string alfavit = txt;   ///объявление алфавита, который используется в тексте
            int kolbukv = koltxt;   ///кол-во букв в алфавите
            char simvol;    ///символьная переменная, нужна для

            int kolvh = 0; ///кол-во вхождений букв в алфавите
            double hx1=0; ///Энтропия для одной буквы
            double hx2 = 0; ///Энтропия для двух букв
            double hx3 = 0;
            double[,] matrix1 = new double[2,kolbukv];  ///массив для хранения данных из однобуквенной таблицы
            string[] alfavit2=new string[koltxt];   ///массив из двубуквенных выражений
            string[] dvebuk= new string[koltxt];

            for (int i = 0; i < kolbukv; i++)
            {
                simvol = alfavit[i];
                
                for (int j = i+1; j < kolbukv; j++)
                {
                    if (alfavit[j]==simvol)     
                    {
                        alfavit=alfavit.Remove(j,1);    ///удаление повторяющейся буквы
                        j--;        ///чтобы после удаления букв, вернулся на место удалённой буквы
                        kolbukv--; ///чтобы не вылез за пределы строки
                    }
                }
            }

            for (int i = 0; i < koltxt-1; i++)              ///двубуквенные выражения
            {
                alfavit2[i] =""+ txt[i] + txt[i + 1];
            }
            alfavit2[koltxt-1] = ""+txt[koltxt-1] + txt[0];
            for (int i = 0; i < koltxt; i++)
            {
                dvebuk[i] = alfavit2[i];
            }

            for (int i = 0; i < koltxt; i++)
            {
                for (int j = i + 1; j < koltxt; j++)
                {
                    if (alfavit2[i] == alfavit2[j])
                    {
                        alfavit2[j] = null;
                    }
                }
            }
            alfavit2 = alfavit2.Where(x => x != null).ToArray();

            int kol_2bukv = alfavit2.Length;                ///кол-во двубуквенных сочетаний
            double[,] matrix2 = new double[2, kol_2bukv];   ///массив для хранения данных из двубуквенной таблицы

            dataGridView1.RowCount = 10;                     ///создание таблицы
            dataGridView1.ColumnCount = kol_2bukv+1;
            dataGridView1.RowHeadersWidth = 80;
            dataGridView1.Rows[0].HeaderCell.Value = "X";
            dataGridView1.Rows[1].HeaderCell.Value = "n";
            dataGridView1.Rows[2].HeaderCell.Value = "w";
            dataGridView1.Rows[3].HeaderCell.Value = "H(X)=";
            dataGridView1.Rows[4].HeaderCell.Value = "XY";
            dataGridView1.Rows[5].HeaderCell.Value = "n";
            dataGridView1.Rows[6].HeaderCell.Value = "w";
            dataGridView1.Rows[7].HeaderCell.Value = "H(XY)=";
            dataGridView1.Rows[8].HeaderCell.Value = "H(X|Y)=";
            dataGridView1.Rows[9].HeaderCell.Value = "I(X,Y)=";
            dataGridView1[kolbukv, 0].Value = "Сумма" ;
            dataGridView1[kolbukv, 1].Value = ""+koltxt;
            dataGridView1[kolbukv, 2].Value = "1";
            dataGridView1[kol_2bukv, 4].Value = "Сумма";
            dataGridView1[kol_2bukv, 5].Value = "" + koltxt;
            dataGridView1[kol_2bukv, 6].Value = "1";


            for (int i = 0; i < kolbukv; i++)                   ///подсчёт данных для однобуквенных сочетаний
            {
                dataGridView1[i, 0].Value = "" + alfavit[i];
                dataGridView1.Columns[i].Width = 50;
                kolvh = 0;
                for (int z = 0; z < koltxt; z++)
                {
                     if (alfavit[i] == txt[z])
                     {
                         kolvh++;
                     }
                }
                dataGridView1[i, 1].Value = kolvh;                  ///заполняется вторая строка
                matrix1[0, i] = kolvh;                               ///заполняется массив вычислений
                dataGridView1[i, 2].Value = kolvh+"/"+koltxt;       ///заполняется третья строка
                matrix1[1, i] = 1.0*kolvh / koltxt;                  ///заполняется массив вычислений

            }
            for (int i = 0; i < kol_2bukv; i++)                 ///подсчёт данных для двубуквенных сочетаний
            {
                dataGridView1[i, 4].Value = "" + alfavit2[i];
                int kol=0;
                for (int j = 0; j < koltxt; j++)
                {
                    if (dvebuk[j]==alfavit2[i])
                    {
                        kol++;
                    }

                }
                dataGridView1[i, 5].Value = kol;
                matrix2[0, i] = kol;
                dataGridView1[i, 6].Value = kol + "/" + koltxt;
                matrix2[1, i] = 1.0 * kol / koltxt;
            }

            for (int i = 0; i < kolbukv; i++)                           ///считает энтропию для однобуквенных сочетаний
            {
                hx1 = hx1 + matrix1[1, i]*Math.Log(matrix1[1,i],2);
            }
            dataGridView1[0, 3].Value =- hx1;

            for (int i = 0; i < kol_2bukv; i++)                            ///считает энтропию для двубуквенных сочетаний
            {
                hx2 = hx2 + matrix2[1, i] * Math.Log(matrix2[1, i], 2);
            }
            dataGridView1[0, 7].Value = -hx2;

            for (int i = 0; i < kolbukv; i++)                            /// Количество информации, которое несет появление первой буквы о второй
            {
                for (int j = 0; j < kol_2bukv; j++)
                {
                    if (alfavit[i]==alfavit2[j][0])
                    {
                        hx3 = hx3 + matrix1[1, i] * matrix2[1, j]*Math.Log(matrix2[1, j], 2);
                    }
                }
                
            }
            dataGridView1[0, 8].Value = -hx3;           ///
            dataGridView1[0, 9].Value = -hx1 + hx3;     /// Количеством информации, которое несет схема У относительно схемы Х
        }
    }
}
